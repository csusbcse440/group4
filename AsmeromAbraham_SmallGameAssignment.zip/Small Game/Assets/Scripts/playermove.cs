﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class playermove : MonoBehaviour 
{

	public float speed;
	public KeyCode jump;
	private Rigidbody rb;
	public float timer;

	public Text coinsText;
	private int count;
	public Text winText;


	private Vector3 respawnPoint;
	private GameObject [] SpeedBoostGO;


	// Use this for initialization
	void Start () 
	{
		rb = GetComponent<Rigidbody> ();
		count = 0;
		respawnPoint = Vector3.zero;
		SpeedBoostGO = GameObject.FindGameObjectsWithTag ("SpeedBoost");
		SetCoinsText ();
		winText.text = "";
	}
	
	// Update is called once per frame
	void FixedUpdate ()
	{
		float moveHorizontal = Input.GetAxis ("Horizontal");

		float moveVertical = Input.GetAxis ("Vertical");

		Vector3 movement = new Vector3 (moveHorizontal, 0.0f, moveVertical);

		rb.AddForce (movement * speed);

		if (Input.GetKeyDown (jump)) {
			transform.rotation = Quaternion.identity;

			rb.AddForce (transform.up * 500.0f);
		}
	

		if (timer >= 0.0f) 
		{
			timer -= Time.deltaTime;
		}

		if (timer <= 0.0f) 
		{
			speed = 10.0f;
		}
	}

	void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.CompareTag ("SpeedBoost")) 
		{
			speed += 10.0f;
			timer += 1.0f;

			other.gameObject.SetActive (false);
		}

		if (other.gameObject.CompareTag ("coin")) 
		{
			count += 1;
			SetCoinsText (); 
			other.gameObject.SetActive (false);

			if (count >= 10) 
			{
				winText.text = " YOU'VE WON ";
			}
		}

		if (other.gameObject.CompareTag ("Lava")) 
		{
			this.gameObject.transform.position = respawnPoint;

			rb.velocity = Vector3.zero;

			foreach (GameObject go in SpeedBoostGO) 
			{
				go.SetActive (true);
			}

		}

		if (other.gameObject.CompareTag ("Respawn")) 
		{
			respawnPoint = other.gameObject.transform.position;
			other.gameObject.SetActive (false);
		}
	}

	void SetCoinsText ()
	{
		coinsText.text = "Coins: " + count.ToString ();
	}
		
}

