﻿using UnityEngine;
using System.Collections;

public class groundMove : MonoBehaviour {

	public KeyCode moveForward;
	public KeyCode moveBackward;
	public KeyCode moveRight;
	public KeyCode moveLeft;

	public GameObject go;


	void FixedUpdate()
	{
		Vector3 groundPosition = transform.position;

		if (Input.GetKey (moveForward)) 
		{
			groundPosition += Vector3.forward;


		}

		if (Input.GetKey (moveBackward)) 
		{
			groundPosition += Vector3.back;
		}

		if (Input.GetKey (moveRight)) 
		{
			groundPosition += Vector3.right;
		}

		if (Input.GetKey (moveLeft)) 
		{
			groundPosition += Vector3.left;
		}
		go.transform.position  = groundPosition;

	}

}
