﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour 
{
	public float speed;

	public KeyCode jump;

	private Rigidbody rb;

	public float timer; 



	// Use this for initialization
	void Start () 
	{
		rb = GetComponent<Rigidbody> ();

	}
	
	// Update is called once per frame
	void FixedUpdate ()
	{
		float moveHorizontal = Input.GetAxis ("Horizontal");

		float moveVertical = Input.GetAxis ("Vertical");

		Vector3 movement = new Vector3 (moveHorizontal, 0.0f, moveVertical);

		rb.AddForce (movement * speed); 

		if (isGrounded == true) 
		{
			
			if (Input.GetKeyDown (jump)) {
				transform.rotation = Quaternion.identity;

				rb.AddForce (transform.up * 500.0f);
			}


			if (timer >= 0.0f) {
				timer -= Time.deltaTime;
			}

			if (timer <= 0.0f) {
				speed = 10.0f;
			}
		}
	}

	private bool isGrounded;

	void OnCollisionStay(Collision coll){
		isGrounded = true;
	}
	void OnCollisionExit(Collision coll){
		if(isGrounded){
			isGrounded = false;   
		}
	}

	void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.CompareTag ("Speed")) 
		{
			speed += 10.0f;
			timer += 15.0f;

			other.gameObject.SetActive (false);
		}

	}

	void OnCollisionEnter(Collision c){
		if (c.gameObject.tag == "Enemy") {

			//You can either use a new Vector 3 
			this.transform.position = new Vector3 (0, 0, 0);

			//or have a GameObject and get its position
			this.transform.position = rb.transform.position;
		}
	}
}

